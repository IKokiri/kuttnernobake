<!DOCTYPE html>
<html lang="pt-br">

<?php $__env->startComponent('site/layout.component_head'); ?>
<?php echo $__env->renderComponent(); ?>

<body>
    <!-- Preloader -->
    <div class="preloader"></div>
     
    <?php $__env->startComponent('site/layout.component_header',["current" => $current]); ?>
    <?php echo $__env->renderComponent(); ?>  

    <?php if (! empty(trim($__env->yieldContent('carousel')))): ?>
        <?php echo $__env->yieldContent('carousel'); ?>
    <?php endif; ?>

    <?php if (! empty(trim($__env->yieldContent('highlights')))): ?>
        <?php echo $__env->yieldContent('highlights'); ?>
    <?php endif; ?>

    <?php if (! empty(trim($__env->yieldContent('page')))): ?>
        <?php echo $__env->yieldContent('page'); ?>
    <?php endif; ?>

    <?php $__env->startComponent('site/layout.component_footer'); ?>
    <?php echo $__env->renderComponent(); ?>   

    <?php $__env->startComponent('site/layout.component_scripts'); ?>
    <?php echo $__env->renderComponent(); ?> 

</body>
<script>

function adicionar_email(){

    field_email = $("#email");

    email = field_email.val();
    
    $.post("/api/newsletter", {email: email}, function(result){
        alert(result.message);
        field_email.val('');
    }).fail(function(result) {
        alert(result.responseJSON.errors['email']);
    })

   
}
$(document).on("click","#enviarEmail",function(){

    assunto = $("#assunto").val();
    nome = $("#nome").val();
    telefone = $("#telefone").val();
    email = $("#email").val();
    empresa = $("#empresa").val();
    mensagem = $("#mensagem").val();

    if(assunto == "" || nome == "" || telefone == "" || email == ""  || empresa == "" || mensagem == ""){
            $("#msgMail").html("Preencha todos os campos.");

            $("#msgMail").removeClass("alert-success")
            $("#msgMail").addClass("alert-danger")
            $("#msgMail").removeClass("hidden")
            return false;
    }

    dados={
        "assunto":assunto,
        "nome":nome,
        "telefone":telefone,
        "email":email,
        "empresa":empresa,
        "mensagem":mensagem
    }

    $.post("/api/contato/orcamento", dados, function(result){
        if(result == "200"){
            $("#msgMail").html("Envio efetuado com sucesso, em breve entraremos em contato");
            $("#msgMail").removeClass("alert-danger")
            $("#msgMail").addClass("alert-success")
            $("#msgMail").removeClass("hidden")
            
        }
    }).fail(function(result) {
        
    })
})

</script>
</html>