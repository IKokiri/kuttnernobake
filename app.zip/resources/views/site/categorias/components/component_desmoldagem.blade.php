<div class="sidebar-widget sidebar-blog-category">
    <ul class="services-cat">
        <li><a href="/SistemaDesmoldagem/ShakeOut#conteudoPrincipal">Shake-Out</a></li>
        <li><a href="/SistemaDesmoldagem/CabineDesmoldagem#conteudoPrincipal">Cabine Desmoldagem</a></li>
        <li><a href="/SistemaDesmoldagem/PreResfriador#conteudoPrincipal">Pré-Resfriador</a></li>
        <li><a href="/SistemaDesmoldagem/TransportePneumatico#conteudoPrincipal">Transporte Pneumático</a></li>
    </ul>
</div> 