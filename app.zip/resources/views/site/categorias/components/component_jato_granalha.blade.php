<div class="sidebar-widget sidebar-blog-category">
    <ul class="services-cat">
        <li><a href="/MaquinasJatoGranalha/JatoPassagemContinua#conteudoPrincipal">Jato de Passagem Contínua</a></li>
        <li><a href="/MaquinasJatoGranalha/JatoGancheiraPassagem#conteudoPrincipal">Jato Gancheira de Passagem</a></li>
        <li><a href="/MaquinasJatoGranalha/JatoGancheiraTipoY#conteudoPrincipal">Jato com Gancheira tipo Y</a></li>
        <li><a href="/MaquinasJatoGranalha/JateamentoBobinas#conteudoPrincipal">Jateamento de Bobinas</a></li>
        <li><a href="/MaquinasJatoGranalha/JatoMesaGiratoria#conteudoPrincipal">Jato Mesa Giratória</a></li>
        <li><a href="/MaquinasJatoGranalha/JatoTamboreamento#conteudoPrincipal">Jato por Tamboreamento</a></li>
    </ul>
</div> 