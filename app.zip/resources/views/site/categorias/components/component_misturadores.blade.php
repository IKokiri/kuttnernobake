<div class="sidebar-widget sidebar-blog-category">
    <ul class="services-cat">
        <li><a href="/Misturadores/MisturadorBracoSimples#conteudoPrincipal">Misturador Braço Simples</a></li>
        <li><a href="/Misturadores/MisturadorBracoDuplo#conteudoPrincipal">Misturador Braço Duplo</a></li>
        <li><a href="/Misturadores/MisturadorMovel#conteudoPrincipal">Misturador Móvel</a></li>
    </ul>
</div>