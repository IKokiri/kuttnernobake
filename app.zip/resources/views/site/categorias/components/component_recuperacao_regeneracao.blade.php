<div class="sidebar-widget sidebar-blog-category">
    <ul class="services-cat">
        <li><a href="/RecuperacaoMecanicaRegeneracaoTermica/RecuperacaoMecanica4TH#conteudoPrincipal">Recuperação Mecânica - 4 T/H</a></li>
        <li><a href="/RecuperacaoMecanicaRegeneracaoTermica/RecuperacaoMecanica430TH#conteudoPrincipal">Recuperação Mecânica - 4 a 30 T/H</a></li>
        <li><a href="/RecuperacaoMecanicaRegeneracaoTermica/RegeneracaoTermica056TH#conteudoPrincipal">Regeneração Térmica - 0,5 a 6 T/H</a></li>
    </ul>
</div> 