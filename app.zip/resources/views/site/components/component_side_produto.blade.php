<!--Blog Category Widget-->
<div class="sidebar-widget sidebar-blog-category">
            <ul class="services-cat">
                <li class="active"><a href="/produto">Misturador Braço Simples</a></li>
                <li><a href="/produto">Misturador Braço Duplo</a></li>
                <li><a href="/produto">Misturador Móvel</a></li>
            </ul>
        </div>