<div class="highlights dark-bg">
    <div class="auto-container">
        <div class="highlight-carousel owl-carousel owl-theme">
            <!-- Highlight Block -->
            <div class="highlight-block">
                <div class="inner-box">
                    <div class="icon-box"><span class="machinery-icon-factory"></span></div>
                    <div class="text">
                        Incorporada no 
                        <a target="_blank" href="https://www.kuettner.com/en/about-us">
                            <strong><span>Grupo Kuttner<span></strong> 
                        </a>    
                        como afiliada da 
                        <a target="_blank" href="http://www.kuttner.com.br">
                            <strong><span>Kuttner do Brasil<span></strong> 
                        </a>    
                        em Junho de 2017.</div>
                </div>
            </div>
            <!-- Highlight Block -->
            <div class="highlight-block">
                <div class="inner-box">
                    <div class="icon-box"><span class="machinery-icon-factory"></span></div>
                    <div class="text">A linha de produtos da  
                        <span><strong>Kuttner No-Bake Solutions</strong></span> é complementada pela linha de produtos tradicionais da <a target="_blank" href="http://www.kuttner.com.br">
                            <strong><span>Kuttner do Brasil<span></strong> 
                        </a>.</div>
                </div>
            </div>
            <!-- Highlight Block -->
            <div class="highlight-block">
                <div class="inner-box">
                    <div class="icon-box"><span class="machinery-icon-factory"></span></div>
                    <div class="text">A Kuttner <strong><span>Kuttner No-Bake Solutions</span></strong> encontra-se instalada em sede própria em Piracicaba / SP.</div>
                </div>
            </div>
        </div>
    </div>
</div>