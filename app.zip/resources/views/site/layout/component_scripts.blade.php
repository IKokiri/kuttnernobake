<div class="scroll-to-top scroll-to-target" data-target="html"><span class="icon fa fa-arrow-up"></span></div>
    <!-- <script src="/js_site/jquery.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="/js_site/bootstrap.min.js"></script>
    <!-- <script src="/js_site/jquery-ui.js"></script> -->
    <script
  src="https://code.jquery.com/ui/1.12.0/jquery-ui.min.js"
  integrity="sha256-eGE6blurk5sHj+rmkfsGYeKyZx3M4bG+ZlFyA7Kns7E="
  crossorigin="anonymous"></script>
    <script src="/js_site/jquery.fancybox.js"></script>
    <script src="/js_site/slick.min.js"></script>    
    <script src="/js_site/mixitup.js"></script>
    <script src="/js_site/owl.js"></script>
    <script src="/js_site/appear.js"></script>
    <script src="/js_site/wow.js"></script>
    <script src="/js_site/script.js"></script>
    <!--Google Map APi Key-->
    <script src="http://maps.google.com/maps/api/js?key=AIzaSyBUkoTXt1bL6oLyPUFFdVQXVlJpxbW-jWQ"></script>
    <script src="/js_site/map-script.js"></script>
    <!--End Google Map APi-->
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->