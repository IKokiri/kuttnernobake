
Olá,

O cliente <strong>{{$nome}}</strong> solicitou um orçamento, que segue:<br>
{{$mensagem}}<br><br>

<strong>DADOS DO CLIENTE</strong><br><br>
Nome: {{$nome}}<br>
Telefone: {{$telefone}}<br>
Email: {{$email}}<br>
Empresa: {{$empresa}}<br>


