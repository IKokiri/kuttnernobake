<!-- Bootstrap core JavaScript-->
  <script src="/admins/vendor/jquery/jquery.min.js"></script>
  <script src="/admins/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="/admins/vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- Custom scripts for all pages-->
  <script src="/admins/js/sb-admin-2.min.js"></script>
  <!-- Page level plugins -->
  <script src="/admins/vendor/chart.js/Chart.min.js"></script>

  <!-- Page level plugins -->
  <script src="/admins/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="/admins/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <!-- Page level custom scripts -->
  <script src="/admins/js/demo/datatables-demo.js"></script>